#load barley data
AG_data<-read.table("AG_for_R.txt", header=T)

#scale data so all markers have mean=0, sd=1
AG_scaled<-as.data.frame(scale(AG_data))

#check scaling worked

mean(AG_scaled$GM1,na.rm=T)
sd(AG_scaled$GM1,na.rm=T)

#calculate a distance matrix
dist_mat<-dist(AG_scaled, method='euclidean')

#use neighbour joining with bootstrapping
tree<-nj(dist_mat)
boot.tree<-boot.phylo(tree,AG_scaled,FUN =function(x) nj(dist(x)),B=100)
plot(tree)
nodelabels(boot.tree,frame="none")

#install and load package for principal co-ordinate analysis (there are many alternatives available)

install.packages("labdsv")
library(labdsv)

#carry out principal co-ordinate analysis
AG_pco<-pco(dist_mat,k=10)

#plot the eigenvalues
plot(AG_pco$eig)

#tabulate percentage variation explained by top 10 eigenvalues
pcntvar<-AG_pco$eig/sum(AG_pco$eig)
pcntvar[1:10]

#plot first two pco axes
plot(AG_pco)

#plot different pairs of pco axes
plot(AG_pco$points[,1],AG_pco$points[,3])

