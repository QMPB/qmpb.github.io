#set directory

setwd("your directory")

#PCA
#install and load special plot library

install.packages("ggfortify")
library(ggfortify)

#load data
teosintepca<-read.table("teosinte_imputed_R.txt", header=T)

#define pca input (markers only, not state name)
pca.input<-teosintepca[c(1:592)]

#run PCA
pca.output<-prcomp(pca.input)

#list first 10 PCAs
summary(pca.output)$importance[,1:10]

#plot Proportion of variance explained by first 10 PCAs

plot(summary(pca.output)$importance[2,1:10], main="PCA analysis - Teosinte", ylab="percentage variance explained", ylim=c(0,0.06),xlab="PCA", lty=par("lty"), lwd=par("lwd"))
lines(summary(pca.output)$importance[2,1:10])

#plot first 2 PCAs

autoplot(pca.output, data=teosintepca, colour='State')

#plot alternative PCs (1 and 3 here)

pca_extra=pca.output
pca_extra$x=pca_extra$x[,c(1,3)]
colnames(pca_extra$x)=c("PC1","PC2")
pca_extra$rotation=pca_extra$rotation[,c(1,3)]
colnames(pca_extra$rotation)=c("PC1","PC2")
autoplot(pca_extra, data=teosintepca,colour='State')+labs(y="PC3")

