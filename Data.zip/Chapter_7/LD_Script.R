#load packages
install.packages("LDcorSV")
library("LDcorSV")
library("ggplot2")
library(RColorBrewer)
colnew<-colorRampPalette(c("grey","red"))(n=99)

#Read in the data (after setting working directory)

Teosintemap<-read.table("Teosintemap.txt",header=T)
Teosinte<-read.table("Teosinte_Chr1.txt",header=T)
Teosinte_state<-read.table("Teosinte_state.txt",header=T)
Teosinte_structurek5<-read.table("Teosinte_structure_k5.txt",header=T)
AGmap<-read.table("AGmap.txt",header=T)
AG<-read.table("AG_Chr1.txt",header=T)
AGpcoa<-read.table("AG_Chr1_pcoa.txt",header=T)

#Teosinte: calculate r^2 without taking account of population structure

Teosinte_No_structure<-LD.Measures(Teosinte,na.presence=TRUE)

#Extract r^2 and the intermarker distances.
Teosinte_No_structure$dist="NA"
nmarkers=82
k<-0
for(i in 1: (nmarkers-1))
{
  for(j in (i+1):nmarkers)
  {
    k<-k+1
    Teosinte_No_structure[k,4]<-abs(Teosintemap[i,3]-Teosintemap[j,3])
  }
}

Teosinte_No_struct_heatmap<-matrix(NA,nrow=nmarkers-1,ncol=nmarkers-1)
k<-0
for(i in 1: (nmarkers-1))
{
  for(j in 1:(nmarkers-1))
  {
    k<-k+1
    ifelse(i<(j+1),Teosinte_No_struct_heatmap[i,j]<-Teosinte_No_structure[k,3], k<-k-1)
  }
}
Teosinte_No_structure$dist<-as.numeric(Teosinte_No_structure$dist)
image(t(Teosinte_No_struct_heatmap),col=colnew)

Teosinte_No_structure_ordered<-Teosinte_No_structure[order(Teosinte_No_structure$dist),]
ggplot(Teosinte_No_structure_ordered, aes(dist,r2))+
    geom_point()+
    ylim(0,1)+
    geom_smooth(formula=Teosinte_No_structure_ordered$r2~ Teosinte_No_structure_ordered$dist,se=F)+
    geom_hline(aes(yintercept=0.1),col="red")


#Teosinte: calculate r^2 taking account of population structure (states)

Teosinte_structure<-LD.Measures(Teosinte,S=Teosinte_state,na.presence=TRUE)


#Extract r^2 and the intermarker distances.
Teosinte_structure$dist="NA"
nmarkers=82
k<-0
for(i in 1: (nmarkers-1))
{
  for(j in (i+1):nmarkers)
  {
    k<-k+1
    Teosinte_structure[k,5]<-abs(Teosintemap[i,3]-Teosintemap[j,3])
  }
}

Teosinte_struct_heatmap<-matrix(NA,nrow=nmarkers-1,ncol=nmarkers-1)
k<-0
for(i in 1: (nmarkers-1))
{
  for(j in 1:(nmarkers-1))
  {
    k<-k+1
    ifelse(i<(j+1),Teosinte_struct_heatmap[i,j]<-Teosinte_structure[k,4], k<-k-1)
  }
}
Teosinte_structure$dist<-as.numeric(Teosinte_structure$dist)
image(t(Teosinte_struct_heatmap),col=colnew )

Teosinte_structure_ordered<-Teosinte_structure[order(Teosinte_structure$dist),]
ggplot(Teosinte_structure_ordered, aes(dist,r2s))+
  geom_point()+
  ylim(0,1)+
  geom_smooth(formula=Teosinte_structure_ordered$r2s~ Teosinte_structure_ordered$dist,se=F)+
  geom_hline(aes(yintercept=0.1),col="red")


#Teosinte: calculate r^2 taking account of population structure (Structure k=5)

Teosinte_structurek5<-LD.Measures(Teosinte,S=Teosinte_structurek5,na.presence=TRUE)


#Extract r^2 and the intermarker distances.
Teosinte_structurek5$dist="NA"
nmarkers=82
k<-0
for(i in 1: (nmarkers-1))
{
  for(j in (i+1):nmarkers)
  {
    k<-k+1
    Teosinte_structurek5[k,5]<-abs(Teosintemap[i,3]-Teosintemap[j,3])
  }
}

Teosinte_structk5_heatmap<-matrix(NA,nrow=nmarkers-1,ncol=nmarkers-1)
k<-0
for(i in 1: (nmarkers-1))
{
  for(j in 1:(nmarkers-1))
  {
    k<-k+1
    ifelse(i<(j+1),Teosinte_structk5_heatmap[i,j]<-Teosinte_structurek5[k,4], k<-k-1)
  }
}
Teosinte_structurek5$dist<-as.numeric(Teosinte_structurek5$dist)
image(t(Teosinte_structk5_heatmap),col=colnew )

Teosinte_structurek5_ordered<-Teosinte_structurek5[order(Teosinte_structurek5$dist),]
ggplot(Teosinte_structurek5_ordered, aes(dist,r2s))+
  geom_point()+
  ylim(0,1)+
  geom_smooth(formula=Teosinte_structurek5_ordered$r2s~ Teosinte_structurek5_ordered$dist,se=F)+
  geom_hline(aes(yintercept=0.1),col="red")



#Barley: calculate r^2 without taking account of population structure

AG_No_structure<-LD.Measures(AG,na.presence=TRUE)

#Extract r^2 and the intermarker distances.
AG_No_structure$dist="NA"
nmarkers=159
k<-0
for(i in 1: (nmarkers-1))
{
  for(j in (i+1):nmarkers)
  {
    k<-k+1
    AG_No_structure[k,4]<-abs(AGmap[i,3]-AGmap[j,3])
  }
}

AG_No_struct_heatmap<-matrix(NA,nrow=nmarkers-1,ncol=nmarkers-1)
k<-0
for(i in 1: (nmarkers-1))
{
  for(j in 1:(nmarkers-1))
  {
    k<-k+1
    ifelse(i<(j+1),AG_No_struct_heatmap[i,j]<-AG_No_structure[k,3], k<-k-1)
  }
}
AG_No_structure$dist<-as.numeric(AG_No_structure$dist)
image(t(AG_No_struct_heatmap), col=colnew)

AG_No_structure_ordered<-AG_No_structure[order(AG_No_structure$dist),]
ggplot(AG_No_structure_ordered, aes(dist,r2))+
  geom_point()+
  ylim(0,1)+
  geom_smooth(formula=AG_No_structure_ordered$r2~ AG_No_structure_ordered$dist,se=F)+
  geom_hline(aes(yintercept=0.1),col="red")


#Barley: calculate r^2 taking account of population structure (pcoas 1 and 2)

AG_structure<-LD.Measures(AG,S=AGpcoa,na.presence=TRUE)


#Extract r^2 and the intermarker distances.
AG_structure$dist="NA"
nmarkers=159
k<-0
for(i in 1: (nmarkers-1))
{
  for(j in (i+1):nmarkers)
  {
    k<-k+1
    AG_structure[k,5]<-abs(AGmap[i,3]-AGmap[j,3])
  }
}

AG_struct_heatmap<-matrix(NA,nrow=nmarkers-1,ncol=nmarkers-1)
k<-0
for(i in 1: (nmarkers-1))
{
  for(j in 1:(nmarkers-1))
  {
    k<-k+1
    ifelse(i<(j+1),AG_struct_heatmap[i,j]<-AG_structure[k,4], k<-k-1)
  }
}
AG_structure$dist<-as.numeric(AG_structure$dist)
image(t(AG_struct_heatmap),col=colnew)

AG_structure_ordered<-AG_structure[order(AG_structure$dist),]
ggplot(AG_structure_ordered, aes(dist,r2s))+
  geom_point()+
  ylim(0,1)+
  geom_smooth(formula=AG_structure_ordered$r2s~ AG_structure_ordered$dist,se=F)+
  geom_hline(aes(yintercept=0.1),col="red")



