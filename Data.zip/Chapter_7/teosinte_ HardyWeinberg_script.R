# install required libraries. adegenet and its associated packages are good for population genetic analysis in R

install.packages("adegenet")
install.packages("pegas")
install.packages("hierfstat")

# load required libraries. adegenet and its associated packages are good for population genetic analysis in R

library(adegenet)
library(pegas)
library(hierfstat)

# read in the data for genotypes and population codes separately. 
genos<-read.table("teosinte_genos_R.txt", header=T)
pops<-read.table("teosinte_pops_R.txt", header=T)

# convert to genind data format

teosinte<- df2genind(genos,ploidy=2,sep="/")

# add in the population information

teosinte@pop<-as.factor(pops$pop)

#check that the data is as expected

teosinte

# make a population genetic summary of the data set considering it as a single population

Teo_Summary<-summary(teosinte)
Teo_Summary

# plot Ho-He for the first 40 markers

barplot(Teo_Summary$Hexp[1:40]-Teo_Summary$Hobs[1:40],xaxt='n',main="He-Ho across all individuals for first 40 loci", ylab= "He-Ho", xlab="Markers")

# calculate F values

Fvalues<-1-(Teo_Summary$Hobs/Teo_Summary$Hexp)

#test for Hardy-Weinberg equilibrium at each marker separately

hwt.all<-hw.test(teosinte, B=0)
hwt.all[1:40,1:3]

# count the number of markers that significantly deviate from HW equilibrium with P<0.05

sum(hwt.all[,3]<0.05)

# Calculate average (se) of Ho, He, F across all markers

se <- function(x) sqrt(var(x)/length(x))
Ho_ave<-round(mean(Teo_Summary$Hobs),4)
Ho_se<-round(se(Teo_Summary$Hobs),4)
He_ave<-round(mean(Teo_Summary$Hexp),4)
He_se<-round(se(Teo_Summary$Hexp),4)
F_ave<-round(mean(Fvalues),4)
F_se<-round(se(Fvalues),4)


Average_table<-data.frame(NA,nrow=5,ncol=3)
Average_table[1,1]<-paste(Ho_ave, "(", Ho_se, ")") 
Average_table[1,2]<-paste(He_ave, "(", He_se, ")")
Average_table[1,3]<-paste(F_ave, "(", F_se, ")")
colnames(Average_table)<-c("Ho", "He", "F")
rownames(Average_table)[1]<-c("All")
Average_table

#test the hypothesis that Hobs>Hexp across all markers

bartlett.test(list(Teo_Summary$Hexp, Teo_Summary$Hobs))
t.test(Teo_Summary$Hexp, Teo_Summary$Hobs, pair=T, var.equal=TRUE, alter="greater")

#separate into "populations" by state:

teosinte_bypop<-seppop(teosinte)
teo.GUE<-summary(teosinte_bypop$GUE)
teo.JAL<-summary(teosinte_bypop$JAL)
teo.MEX<-summary(teosinte_bypop$MEX)
teo.MIC<-summary(teosinte_bypop$MIC)

# repeat above analysis for MEX only

teo.MEX

barplot(teo.MEX$Hexp[1:40]-teo.MEX$Hobs[1:40], xaxt='n', main="He-Ho in MEX for first 40 loci ", ylab= "He-Ho", xlab="Markers")

Fvalues<-1-(teo.MEX$Hobs/teo.MEX$Hexp)

hwt.MEX<-hw.test(teosinte_bypop$MEX, B=0)
hwt.MEX[1:40,1:3]
sum(hwt.MEX[,3]<0.05)

Ho_ave.MEX<-round(mean(teo.MEX$Hobs),4)
Ho_se.MEX<-round(se(teo.MEX$Hobs),4)
He_ave.MEX<-round(mean(teo.MEX$Hexp),4)
He_se.MEX<-round(se(teo.MEX$Hexp),4)
F_ave.MEX<-round(mean(Fvalues),4)
F_se.MEX<-round(se(Fvalues),4)

Average_table[2,1]<-paste(Ho_ave.MEX, "(", Ho_se.MEX, ")") 
Average_table[2,2]<-paste(He_ave.MEX, "(", He_se.MEX, ")")
Average_table[2,3]<-paste(F_ave.MEX, "(", F_se.MEX, ")")
rownames(Average_table)[2]<-c("MEX")
Average_table

bartlett.test(list(teo.MEX$Hexp, teo.MEX$Hobs))
t.test(teo.MEX$Hexp, teo.MEX$Hobs, pair=T, var.equal=TRUE, alter="greater")

#for other populations, I have compiled the data in the exercise



