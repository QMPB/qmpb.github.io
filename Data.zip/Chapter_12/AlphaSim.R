#Generate Founder haplotypes
founderPop = runMacs(nInd=50, nChr=21, segSites=1000, inbred=TRUE)

#Set Global parameters
SP=SimParam$
  new(founderPop)$
  addTraitA(1000)$
  setVarE(H2=0.4)

#Simulate first year of programme
Parents = newPop(founderPop)
F1 = randCross(Parents, 200)

#2nd and 3rd years
HDRW = makeDH(F1, 100)
HDRW = setPheno(HDRW, varE=9) #H2=0.1

#Evaluation in preliminary yield trial
PYT = selectWithinFam(HDRW, 5)
PYT = setPheno(PYT)

#Evaluation in advanced yield trial
AYT = selectInd(PYT, 100)
AYT = setPheno(AYT, reps=4)

#Elite yield trial
EYT = selectInd(AYT, 10)
EYT = setPheno(EYT, reps=16)

#Variety release!
Variety = selectInd(EYT, 1)

#Evaluation
yield = list(Parents=gv(Parents), F1=gv(F1),
             HDRW=gv(HDRW), 
             PYT=gv(PYT), 
             AYT=gv(AYT), 
             EYT=gv(EYT),
             Variety=gv(Variety))
boxplot(yield, ylab="Genetic Value")
yield$Variety

THIS IS END OF MAIN SCRIPT



THIS IS LOOP SCRIPT

#run 10 replicates
variety_yields<-matrix(NA,10,1)

for(i in 1:10)
{

  founderPop = runMacs(nInd=50, nChr=21, segSites=1000, inbred=TRUE)
  SP=SimParam$
    new(founderPop)$
    addTraitA(1000)$
    setVarE(H2=0.4)
  Parents = newPop(founderPop)
  F1 = randCross(Parents, 200)
  HDRW = makeDH(F1, 100)
  HDRW = setPheno(HDRW, varE=9)
  PYT = selectWithinFam(HDRW, 4)
  PYT = setPheno(PYT)
  AYT = selectInd(PYT, 125)
  AYT = setPheno(AYT, reps=4)
  EYT = selectInd(AYT, 10)
  EYT = setPheno(EYT, reps=16)
  Variety = selectInd(EYT, 1)
  yield = list(Parents=gv(Parents), F1=gv(F1),
              HDRW=gv(HDRW), 
              PYT=gv(PYT), 
              AYT=gv(AYT), 
              EYT=gv(EYT),
              Variety=gv(Variety))
  variety_yields[i,1]<-yield$Variety
  }

mean(variety_yields)
