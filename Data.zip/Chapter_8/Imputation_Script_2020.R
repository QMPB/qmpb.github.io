### Imputing missing data with softImpute
### IJM 21 February 2014, KAG March 2019

install.packages("missForest")
install.packages("softImpute")
library(missForest)
library(softImpute)

# Read in your dataset (REMEMBER TO CHANGE THE INPUT FILE TO THE ONE SELECTED FOR YOUR GROUP)

magic.data<-read.table("magic.lt.1.0.txt")

dim(magic.data)					# There should be 710 lines in the dataset

# Sample 500 markers at random

sample.500<-magic.data[,sort(sample(1:dim(magic.data)[2],500,replace=FALSE))]



# Delete ~10%

missing<-sample.500
for (i in 1:710) {
  for (j in 1:500)  {
    if(runif(1) <0.1) missing[i,j]<-NA
  }
  #print(i)
}
dim(missing)


################################################

# For softImpute, scale the data

missing.scale<-biScale(missing,row.center=F,row.scale=F,col.center=T,col.scale=T)


# Carry out the imputation. Alter rank.max as desired. 100 is good for this dataset

date()
missing.scale.imp<-softImpute(missing.scale,rank.max=100,lambda=0)
date()


# Create a copy of the data with the missing values imputed and unscaled.

missing.imp<-complete(missing,missing.scale.imp,unscale=T)


# Look at the plots to see what the imputed data look likes. Plots imputed data only.

boxplot(missing.imp[is.na(missing)]~sample.500[is.na(missing)],main="distribution of imputed data",ylab="imputed",xlab="original")
hist(missing.imp[is.na(missing)][sample.500[is.na(missing)]==1],breaks=1000,main="imputed hets")
hist(missing.imp[is.na(missing)][sample.500[is.na(missing)]==2],breaks=1000,main="imputed homs (2)")
hist(missing.imp[is.na(missing)][sample.500[is.na(missing)]==0],breaks=1000,main="imputed homs (0)")



# Round the imputed numbers to integers (ie to genotype classes)

missing.imp.round<-round(missing.imp)


# Look at the plots again

boxplot(missing.imp.round[is.na(missing)]~sample.500[is.na(missing)],main="distribution of imputed data",ylab="imputed",xlab="original")
hist(missing.imp.round[is.na(missing)][sample.500[is.na(missing)]==1],breaks=1000,main="imputed hets")
hist(missing.imp.round[is.na(missing)][sample.500[is.na(missing)]==2],breaks=1000,main="imputed homs (2)")
hist(missing.imp.round[is.na(missing)][sample.500[is.na(missing)]==0],breaks=1000,main="imputed homs (0)")


# Some values are outside the range. Set these to the closest homozyous class.

missing.imp.round[missing.imp.round>2]<-2
missing.imp.round[missing.imp.round<0]<-0


# Create a table of results and calculate a chi sq - high values indicate good imputation.

imp.test<-table(missing.imp.round[is.na(missing)],sample.500[is.na(missing)],dnn=c("imputed","original"))
imp.test
chisq.test(imp.test)


#################################################

# SVD imputation except impute homs only - round up or down to the nearest

missing.imp.round.2<- 2*round(missing.imp/2)   # imputed data is all 0 or 2
missing.imp.round.2[missing.imp.round.2>2]<-2
missing.imp.round.2[missing.imp.round.2<0]<-0
imp.test.2<-table(missing.imp.round.2[is.na(missing)],sample.500[is.na(missing)],dnn=c("imputed","       original"))
imp.test.2
chisq.test(imp.test.2)



# Have a stab at finding a suitable value for rank.max

#First, calculate the columne means

av<-colMeans(missing,na.rm=T)	

#Now replace the missing data with the means

missing.imp.av<-missing		
for (i in 1:500) {
  missing.imp.av[is.na(missing[,i]),i]<-av[i]
}

svd.imp<-svd(missing.imp.av)		# Get out the eigenvalues
par(mfcol=c(1,2),cex=0.5)
plot(svd.imp$d[-1])			# plot them
plot(ecdf(svd.imp$d[-1]))		# plot the empirical cumulative distribution

#################################################

#  Impute using just the mean.

av<-colMeans(missing,na.rm=T)		
missing.imp.av<-missing		

for (i in 1:500) {
  missing.imp.av[is.na(missing[,i]),i]<-av[i]	# replace missing values with the mean allele frequency
}


# Round the data up and down as before.
missing.imp.av<-round(missing.imp.av)
missing.imp.av[missing.imp.av>2]<-2
missing.imp.av[missing.imp.av<0]<-0


# Create a table of results as before

imp.test.av<-table(missing.imp.av[is.na(missing)],sample.500[is.na(missing)],dnn=c("imputed","       original"))
imp.test.av
chisq.test(imp.test.av)

#####################################

#missForest

# convert to factor

missing.factor<-missing
missing.factor[]<-lapply(missing.factor,factor)

# Impute 

date()
missing.imp.forest<-missForest(missing.factor,ntree=10,mtry=20) # ie 10 trees (default), 20 markers at each split
date()

#Note default imputation would be: 
# missing.imp.forest<-missForest(missing.factor) # (default = ntree = 100, mtry = sqrt(no. markers)

mixError(missing.imp.forest$ximp,missing,sample.500) # takes time. Values close to 0 good. Close to 1 bad.


chi.forest<-table(missing.imp.forest$ximp[is.na(missing)],sample.500[is.na(missing)],dnn=c("imputed","       original"))
chi.forest
chisq.test(chi.forest) 



