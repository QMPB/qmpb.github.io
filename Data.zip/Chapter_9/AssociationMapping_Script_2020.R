#load the package

install.packages("rrLUP")
install.packages("C:/Users/x991630/Desktop/GWASpoly_download/GWASpoly_1.3.tar.gz", repos = NULL, type = "source")

require(GWASpoly)

# Read in data
TGall<-read.GWASpoly(ploidy=1,"TGphens.csv","TGgeno.csv","numeric",n.traits=18,delim=",")
TGkin<-read.GWASpoly(ploidy=1,"TGphens.csv","TGkin.csv","numeric",n.traits=18,delim=",")


# Calculate kinship 
TGall<-set.K(TGall) 
TGkin<-set.K(TGkin)
TGall@K[1:5,1:5]
TGkin@K[1:5,1:5]

# Examine population structure
plot(eigen(TGall@K)$values)			
plot(eigen(TGkin@K)$values)
plot(eigen(TGall@K)$vectors[,1:2])
plot(eigen(TGkin@K)$vectors[,1:2])

# Swap in kinship matrix calculated with thinned markers
TGanalysisUnthinned<-TGall 
TGanalysisThinned<-TGall
TGanalysisThinned@K<-TGkin@K 

# check
TGanalysisUnthinned@K[1:5,1:5]
TGanalysisThinned@K[1:5,1:5]

# Do the GWAS for all traits
TG.GWAS.Thinned<-GWASpoly(TGanalysisThinned,models="additive") 

# On HT and FT only
TG.HT.FT.Thinned<-GWASpoly(TGanalysisThinned, models="additive", traits=c("HT","FT")) 

#run the q-q plots

qq.plot(TG.HT.FT.Thinned,trait="FT",model="additive")
qq.plot(TG.HT.FT.Thinned,trait="HT",model="additive")

#set significance threshold

TG.HT.FT.Thinned.Bonf<-set.threshold(TG.HT.FT.Thinned,method="Bonferroni",level=0.05) 
TG.HT.FT.Thinned.fdr<-set.threshold(TG.HT.FT.Thinned,method="FDR",level=0.05) 

#if you have time (default should be 1000 permutations)
TG.HT.FT.Thinned.perm<-set.threshold(TG.HT.FT.Thinned,method="permute",level=0.05,n.permute=100) 


# Examine results 
manhattan.plot(TG.HT.FT.Thinned.Bonf,trait=c("HT"),model="additive")
manhattan.plot(TG.HT.FT.Thinned.fdr,trait=c("HT"),model="additive")
manhattan.plot(TG.HT.FT.Thinned.perm,trait=c("HT"),model="additive")

get.QTL(TG.HT.FT.Thinned.Bonf)
get.QTL(TG.HT.FT.Thinned.fdr)
get.QTL(TG.HT.FT.Thinned.perm)

boxplot(TG.HT.FT.Thinned.Bonf@pheno$FT~as.data.frame(TG.HT.FT.Thinned.Bonf@geno)$PpdD1_297,varwidth=T)
boxplot(TG.HT.FT.Thinned.Bonf@pheno$HT~as.data.frame(TG.HT.FT.Thinned.Bonf@geno)$Rht2_400,varwidth=T)

#analysis with Unthinned kinship markers
TG.HT.FT.Unthinned<-GWASpoly(TGanalysisUnthinned, models="additive", traits=c("HT","FT")) 
TG.HT.FT.Unthinned.fdr<-set.threshold(TG.HT.FT.Unthinned,method="FDR",level=0.05) 
manhattan.plot(TG.HT.FT.Unthinned.fdr,trait=c("HT"),model="additive")
get.QTL(TG.HT.FT.Unthinned.fdr)


# Do the analysis completely unadjusted for kinship
TGdiag<-TGanalysisThinned
TGdiag@K<-diag(1,length(rownames(TGanalysisThinned@geno)))
rownames(TGdiag@K)<-(rownames(TGanalysisThinned@geno))
colnames(TGdiag@K)<-(rownames(TGanalysisThinned@geno))

TGdiag@K[1:5,1:5]
TGdiag <-GWASpoly(TGdiag,models="additive",traits=c("HT","FT"))
TGdiag.fdr <-set.threshold(TGdiag,method="FDR",level=0.05)
get.QTL(TGdiag.fdr)
manhattan.plot(TGdiag.fdr,trait=c("HT"),model="additive")


# Do GWAS adjusted for RHT2 as a covariate
summary(TGanalysisThinned@fixed) 
Rht2<- set.params(fixed=c("Rht2_400"),fixed.type=c("numeric"))
TG.HT.Rht2<-GWASpoly(TGanalysisThinned,models="additive",trait=c("HT"),params=Rht2)
TG.HT.Rht2 <-set.threshold(TG.HT.Rht2,method="FDR",level=0.05)

# Compare results
get.QTL(TG.HT.Rht2,traits=c("HT"))
get.QTL(TG.HT.FT.Thinned.fdr,traits=c("HT"))


# Do a Q+K analysis
params <- set.params(n.PC=10) 
TG.PCO<-GWASpoly(TGanalysisThinned,models="additive",traits=c("HT","FT"),params=params)
TG.PCO<-set.threshold(TG.PCO,method="FDR",level=0.05)

# Compare results
get.QTL(TG.PCO)
get.QTL(TG.HT.FT.Thinned.fdr)

qq.plot(TG.PCO,trait="FT",model="additive")
qq.plot(TG.HT.FT.Thinned,trait="FT",model="additive")


# Analyse with countries as a covariate

country<-set.params(fixed = "COUNTRY",fixed.type = "factor") 
TG.country<-GWASpoly(TGanalysisThinned,models="additive",traits=c("HT","FT"), params=country)
TG.country<-set.threshold(TG.country,method="FDR",level=0.05)

# Compare results
get.QTL(TG.country)
get.QTL(TG.HT.FT.Thinned.fdr)

