install.packages("qtl2")
library(qtl2)

#read in the data
NIAB_MAGIC<-read_cross2("MAGIC.yaml")

#insert pseudomarkers (to estimate parentage at 1cM intervals)
map <- insert_pseudomarkers(NIAB_MAGIC$gmap, step=1)

#calculate genotype probabilities and convert to allele probabilties 
pr <- calc_genoprob(NIAB_MAGIC, map, error_prob=0.002)
apr <- genoprob_to_alleleprob(pr)

#calculate kinship using only the evenly spread pseudomarkers
grid <- calc_grid(NIAB_MAGIC$gmap, step=1)
pr_grid <- probs_to_grid(pr, grid)
kinship_grid <- calc_kinship(pr_grid)

#alternative kinship calculation with loco
kinship_loco <- calc_kinship(apr, "loco")

# carry out a genome scan 

out_grid <- scan1(apr, NIAB_MAGIC$pheno, kinship_grid)
out_loco <- scan1(apr, NIAB_MAGIC$pheno, kinship_loco)

#carry our permutation tests
permtest<-scan1perm(pr,NIAB_MAGIC$pheno,n_perm=1000)
summary(permtest,alpha=c(0.2,0.05))

#plot QTL results for "loco" method
par(mar=c(4.1, 4.1, 0.6, 0.6))
ymx <- maxlod(out_loco)
par(mfrow=c(2,1))
plot(out_loco, NIAB_MAGIC$gmap,lodcolumn=1,ylim=c(0, ymx*1.02))
abline(h=6.68,lty=2)
legend("topright",lwd=2,c("2012"),bg="gray90")
plot(out_loco, NIAB_MAGIC$gmap, lodcolumn=2,ylim=c(0, ymx*1.02))
abline(h=6.69,lty=2)
legend("topright",lwd=2,c("2013"),bg="gray90")

#plot on same figure
par(mfrow=c(1,1))
plot(out_loco, NIAB_MAGIC$gmap,lodcolumn=1,col="blue",ylim=c(0, ymx*1.02))
plot(out_loco, NIAB_MAGIC$gmap, lodcolumn=2,col="green", add=TRUE)
abline(h=6.68,lty=2)
legend("topright",lwd=2,col=c("blue","green"),colnames(out_loco),bg="gray90")

#compare "loco" and grid methods for 2013

par(mfrow=c(2,1))
plot(out_loco, NIAB_MAGIC$gmap,lodcolumn=2,col="blue",ylim=c(0, ymx*1.02))
abline(h=6.69,lty=2)
legend("topright",lwd=2,c("2013_loco"),bg="gray90")
plot(out_grid, NIAB_MAGIC$gmap,lodcolumn=2,col="blue",ylim=c(0, ymx*1.02))
abline(h=6.69,lty=2)
legend("topright",lwd=2,c("2013_grid"),bg="gray90")

#find the peaks and their intervals, peakdrop indicates the amount that the 
#LOD curve must drop below the lowest of two adjacent peaks.
find_peaks(out_loco, map, threshold=6.69, peakdrop=1.8, drop=1.5)

#plot allelic effects for chromosome 6 (2013 phenotype)
par(mfrow=c(1,1))
col <- c("#FFDC00","#888888","#F08080","#0064C9","#7FDBFF","#2ECC40","#FF4136","#B10DC9")
legend<-c("ALC","BRO","CLA","HER","RIA","ROB","SOI","X19")
coef_c2 <- scan1coef(apr[,"6"], NIAB_MAGIC$pheno[,2])
par(mar=c(4.1, 4.1, 0.6, 0.6))
plot_coef(coef_c2[,1:8], NIAB_MAGIC$gmap["6"], col=col, scan1_output=out_loco, bgcolor="gray95", legend="bottomright")


#and for chromosome 10
coef_c2 <- scan1coef(apr[,"10"], NIAB_MAGIC$pheno[,2])
par(mar=c(4.1, 4.1, 0.6, 0.6))
plot_coef(coef_c2[,1:8], NIAB_MAGIC$gmap["10"], col=col, scan1_output=out_loco, bgcolor="gray95", legend="bottomleft")

