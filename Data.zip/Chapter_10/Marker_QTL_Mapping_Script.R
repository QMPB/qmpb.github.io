#load packages
library(qtl)
library(ASMap)

#Read the data in to R/qtl

AxC<-read.cross("csv",,"AxC_R.csv",genotypes=c("A","B"),estimate.map=F) 
class(AxC)[1]<-"dh"

#summarise the input data
summary(AxC) 
plot(AxC)

#make a quick map (and then remove it!)
quick.map <-est.rf(AxC) 
quick.map <-formLinkageGroups(quick.map,reorgMarkers=T) 
quick.map <-orderMarkers(quick.map)
plotMap(quick.map) 
rm(quick.map)

#Estimate and examine recombination fractions

AxC<-est.rf(AxC)
pull.rf(AxC)[1:5,1:5]
hist(pull.rf(AxC),breaks=40)
hist(pull.rf(AxC,what="lod")) 
hist(pull.rf(AxC,what="lod"),ylim=c(0,200),breaks=40)
plot(pull.rf(AxC,what="rf")[,],pull.rf(AxC,what="lod")[,],xlab="rf",ylab="lod")

#Form and examine linkage groups
test.linkage.groups<-formLinkageGroups(AxC,reorgMarkers=T,verbose=T,min.lod=3,max.rf=0.25) 
plotRF(test.linkage.groups)
plotRF(AxC)
AxC <-formLinkageGroups(AxC,reorgMarkers=T, verbose=T,min.lod=??,max.rf=??) 

#Order markers
test<-orderMarkers(AxC,use.ripple=F)
plotRF(test)
plotRF(AxC)
plot.map(test)

#Rippling
chr1.ripple4<-ripple(AxC,chr=1) 	 	# ripple chr 1 with defaults 
chr1.ripple7<-ripple(AxC,chr=1,window=7) 	# increase window size 
chr1.ripple4.like<-ripple(AxC,chr=1,method="likelihood") # use likelihood 
summary(chr1.ripple4)


pull.map(AxC,chr=1)  	#  Existing map 
AxC.v2<-switch.order(AxC,chr=1,order=chr1.ripple7[2,]) # switch order (make sure get correct row) 
pull.map(AxC.v2,chr=1) 	#  Compare new order with the initial order 
rm(AxC.v2)  	 		#  Tidy up 
test<-switch.order(test,chr=1,order=summary(chr1.ripple7)[2,])

#changing the genotyping error rate
err.pr.order<-orderMarkers(test,use.ripple=F,error.prob=0.01) 
plotMap(err.pr.order,test)
plotMap(err.pr.order,test,chr=1)

#Making a map for all chromsomes, with default ripple parameters (window=4)
AxC<-read.cross("csv",,"AxC_R.csv",genotypes=c("A","B"),estimate.map=F)
AxC<-est.rf(AxC) 
AxC<-formLinkageGroups(AxC,reorgMarkers=T) 
AxC<-orderMarkers(AxC,use.ripple=T) 
write.cross(AxC,"csv",filestem="AxCmapped")

#calculating and plotting error lods
AxC<-calc.errorlod(AxC)
plotErrorlod(AxC)
plotErrorlod(AxC,chr=2) 
top.errorlod(AxC,2,2)
pull.map(AxC,2)
plotGeno(AxC,2)

#other marker mapping QC tools
plotRF(AxC)  
plotRF(AxC,chr=1:5)
plotRF(AxC,chr=1)

#ASMap - load data
ASMaptest<-mstmap.cross(AxC) 
AxC.mst<-read.table("AxC_ASmap.txt",header=T,colClasses = "character")

#ASMap - make a map and examine it
AxC.mst.map<-mstmap.data.frame(AxC.mst)
plot.map(mstmap.data.frame(AxC.mst,p.value = 1e-06))
heatMap(AxC.mst.map,chr=L10) # LOD at the bottom rf at the top
plotRF(AxC.mst.map)
profileGen(AxC.mst.map,chr="L3") 
profileMark(AxC.mst.map,chr="L3")

#QTL mapping - estimate genotype probabilities along each chromosome
AxC<-calc.genoprob(AxC,2)

#QTL mapping - scanone
ResultPhen3<-scanone(AxC,pheno.col=3)
plot(ResultPhen3)
scanone.result<-scanone(AxC, pheno.col=3,model="normal",method="hk") 
summary(scanone.result) 
plot(scanone.result) 
max(scanone.result)        
find.marker(AxC,chr=6,pos = 14.1)
plotPXG(AxC,pheno.col=3,"AFLP24") 
scanone.perm<-scanone(AxC,pheno.col=3,model="normal",method="hk",n.perm=1000) 
summary(scanone.perm)

#QTL mapping - covariates
max(scanone(AxC,chr=6,pheno.col=3)) 
covariate_1<-pull.geno(AxC)[,"AFLP24"]
scan.result.cov<-scanone(AxC,pheno.col=3,model="normal",method="hk",addcov=covariate_1)

#QTL mapping - scantwo
scan2.res<-scantwo(AxC,pheno.col=3,method="hk")  
summary(scan2.res)
scantwo_perm<-(scantwo(AxC,pheno.col=3,method="hk",n.perm=10,chr=c(1:30))) 
max(scantwo_perm$int)
max(scan2.res)
plot(scan2.res)

#QTL mapping - CIM
cim_out<-cim(AxC,pheno.col=3,n.marcovar=5,window=10,method="hk") 
plot(cim_out) 
plot(cim_out,chr=c(6,9))
summary(cim_out)
cim_perm<-cim(AxC,pheno.col=3,n.marcovar=5,window=10,method="hk",n.perm=100) 
summary(cim_perm) 
max(cim_perm) 

